﻿This directory contains an output in CreateUIDefinition.json/basics that matches to a parameter in AzureDeploy.json

﻿This directory contains a CreateUIDefinition that outputs a property not found in AzureDeploy.

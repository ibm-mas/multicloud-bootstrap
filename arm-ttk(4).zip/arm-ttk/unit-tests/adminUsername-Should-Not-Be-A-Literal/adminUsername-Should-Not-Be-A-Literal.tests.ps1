﻿
#requires -module arm-ttk
. $PSScriptRoot\..\arm-ttk.test.functions.ps1
Test-TTK $psScriptRoot
return        


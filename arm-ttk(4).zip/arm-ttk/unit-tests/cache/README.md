﻿
# Running Tests

When running unit tests, use the cache files here, so that a new update doesn't break the tests.

Also set the test date to on or close to the date of the cache files

This was copied from [the Azure Quickstart Repository - 100-marketplace-sample](https://github.com/Azure/azure-quickstart-templates/tree/master/100-marketplace-sample),

as an example of how to include sample test templates in this repository. 


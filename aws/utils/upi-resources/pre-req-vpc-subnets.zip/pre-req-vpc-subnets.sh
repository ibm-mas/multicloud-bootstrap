#!/bin/bash
terraform -v
echo "Initializing terraform...."
terraform init -input=false

echo "Terraform plan...."
terraform plan -out=tfplan -input=false

echo "Terraform apply...."
terraform apply "tfplan"
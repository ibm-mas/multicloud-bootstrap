Objective:
To create all the pre-requisite network resources for use in UPI stack deployment

Pre-requisites:
Terraform should be installed.

Steps:
1) Unzip this zip file into a directory (eg., temp_dir)
2) Run the aws configure command & enter your AWS account access key ID & access key & select the region where you want to create these network resources. 
A sample command run will look as follows:

[temp_dir]# aws configure
AWS Access Key ID [None]: <Enter Access Key ID>
AWS Secret Access Key [None]: <Enter Access Key>
Default region name [None]: <Enter your region where you want VPC & subnets to be created. For eg., us-east-1>
Default output format [None]: <This can be left blank>

3) From temp_dir, run the pre-req-vpc-subnets.sh file & it should create all required network resources such as VPC, subnets, elastic ip's, NAT & intergnet gateway & other network resources.